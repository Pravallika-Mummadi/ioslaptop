//
//  ViewController.swift
//  DictionaryApp
//
//  Created by Pesarlanka,Siva Bhargavi on 11/28/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "dictCell", for: indexPath)
        
        cell.textLabel?.text = words[indexPath.row][0]
        
        return cell
        
        
    }
    
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var words = [["Benevolent 🤗", "Well-meaning and kindly"],
                 ["Courage ✊","The ability to do something that frightens one"],
                 ["Joy 🥳","Happiness"]
                ]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "meaningSegue"){
            let destination = segue.destination as!
                DisplayMeaningViewController
            destination.word = words[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }

    
}

