//
//  DisplayMeaningViewController.swift
//  DictionaryApp
//
//  Created by Pesarlanka,Siva Bhargavi on 11/28/23.
//

import UIKit

class DisplayMeaningViewController: UIViewController {
    
    @IBOutlet weak var displayWord: UILabel!
    
    @IBOutlet weak var displayMeaningOL: UILabel!
    
    var word:[String] = []
    //var meaning:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayMeaningOL.text = "The meaning of the word is \(word[1])"
        displayWord.text = "\(word[0])"
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
