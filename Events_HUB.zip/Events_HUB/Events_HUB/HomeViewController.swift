//
//  ViewController.swift
//  Events_HUB
//
//  Created by Lalith Vuppala on 11/28/23.
//

import UIKit

class HomeViewController: UIViewController {
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
     
    }
    

}

