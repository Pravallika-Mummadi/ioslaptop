//
//  eventsData.swift
//  Events_HUB
//
//  Created by Lalith Vuppala on 11/28/23.
//

import Foundation

struct eventDetails {
    var event : String?
    var details: [events]
}

struct events {
    var eventName: String?
    var venue: String?
    var date: String?
    var time: String?
    var address: String?
    var sponsor: String?
}

let eventNamesArray = [
    "Ganesh Chaturdi",
    "ISA meet",
    "Farewell"
]

// Use an array of eventDetails for each key in the dictionary
var eventArray: [String: [eventDetails]] = [
    "Ganesh Chaturdi" : [eventDetails(details: [events(eventName: "Event1", venue: "Venue1", date: "Date1", time: "Time1", address: "Address1", sponsor: "Sponsor1")])],
    "ISA meet" : [eventDetails(details: [events(eventName: "Event2", venue: "Venue2", date: "Date2", time: "Time2", address: "Address2", sponsor: "Sponsor2")])],
    "Farewell" : [eventDetails(details: [events(eventName: "Event2", venue: "Venue2", date: "Date2", time: "Time2", address: "Address2", sponsor: "Sponsor2")])]
]


