//
//  ContactDetailsViewController.swift
//  Exam3Pratice
//
//  Created by Charishma Chowdary Bandaru on 11/28/23.
//

import UIKit

class wordViewController: UIViewController {

    @IBOutlet weak var displayOL: UILabel!
    
    @IBOutlet weak var display1OL: UILabel!
    var word = ""
    var meaning = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        displayOL.text = "Word: \((word?.word)!)"
//        display1OL.text = "meaning: \((word?.meaning)!)"
        displayOL.text! += word
        display1OL.text! += meaning
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
