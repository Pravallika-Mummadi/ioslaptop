//
//  ViewController.swift
//  Exam3Pratice
//
//  Created by Charishma Chowdary Bandaru on 11/28/23.
//

import UIKit


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return w.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = wordTableView.dequeueReusableCell(withIdentifier: "wordCell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = w[indexPath.row][0]
        
        //return the cell
        return cell
    }
    
    
    
 
    @IBOutlet weak var wordTableView: UITableView!
    

    var w = [["Benevolent 🤗","Well-meaning and kindly"],["Courage 🦸‍♂️","The ability to do something that frightens one."],["Genuine 🌼","ruly what something is said to be; authentic."],["Hope 🌟","A feeling of expectation and desire for paticular thing to happen."],["Resilient 🌱", "Able to withstand or recover quickly from difficult conditions."],["Sad 😢",  "Feeling or showing sorrow; unhappy."],["Serene 🌅",  "Calm, Peaceful, and untrobuled."],["Joy 😊", "A feeling of great pleasure and happiness"],["Kindness 💖","The quality of being friendly,generous, and considerate."],["Peace ✌️","A state of tranquility or quiet"]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        let w1 = Word(word: "Benevolent 🤗", meaning: "Well-meaning and kindly")
//        let w2 = Word(word: "Courage 🦸‍♂️", meaning: "The ability to do something that frightens one.")
//        let w3 = Word(word: "Genuine 🌼", meaning: "ruly what something is said to be; authentic.")
//        let w4 = Word(word: "Hope 🌟", meaning: "A feeling of expectation and desire for paticular thing to happen.")
//        let w5 = Word(word: "Resilient 🌱", meaning: "Able to withstand or recover quickly from difficult conditions.")
//        let w6 = Word(word: "Sad 😢", meaning: "Feeling or showing sorrow; unhappy.")
//        let w7 = Word(word: "Serene 🌅", meaning: "Calm, Peaceful, and untrobuled.")
//        let w9 = Word(word: "Joy 😊", meaning: "A feeling of great pleasure and happiness")
//        let w10 = Word(word: "Kindness 💖", meaning: "The quality of being friendly,generous, and considerate.")
//        let w11 = Word(word: "Peace ✌️", meaning: "A state of tranquility or quiet")
//
//        words.append(w1)
//        words.append(w2)
//        words.append(w3)
//        words.append(w4)
//        words.append(w5)
//        words.append(w6)
//        words.append(w7)
//        words.append(w9)
//        words.append(w10)
//        words.append(w11)
//
        
        
        
        wordTableView.delegate = self
        wordTableView.dataSource = self
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition  = segue.identifier
        
        if(transition == "wordSegue")
        {
            let destination = segue.destination as! wordViewController
            
//            destination.word = words[(wordTableView.indexPathForSelectedRow?.row)!]
            destination.word = w[(wordTableView.indexPathForSelectedRow?.row)!][0]
            destination.meaning = w[(wordTableView.indexPathForSelectedRow?.row)!][1]
            
        }
    }


}

