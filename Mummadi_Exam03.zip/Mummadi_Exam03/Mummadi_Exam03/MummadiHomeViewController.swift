//
//  ViewController.swift
//  Mummadi_Exam03
//
//  Created by Pravallika Mummadi on 11/30/23.
//

import UIKit

class MummadiHomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return C.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = MummadiTVOL.dequeueReusableCell(withIdentifier: "MummadiCell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = C[indexPath.row][0]
        
        //return the cell
        return cell
    }
    

    
  
    @IBOutlet weak var MummadiTVOL: UITableView!
    
    
    var C = [["Alex Brown","660-215-0047"],
             ["Ava Robinson","123-456-7891"],
             ["Bob Johnson","987-654-3211"],
             ["Divya Anumolu","876-543-2122"],
             ["Jagadeesh Ponnam","987-657-6372"],
             ["Jane Smith","987-253-6372"],
             ["John Doe","123-456-7891"],
             ["Micheal Johnson","123-263-7891"],
             ["Pratap Kuchi","123-456-5432"],
             ["Venkat Thumati","123-345-7891"]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        MummadiTVOL.delegate = self
        MummadiTVOL.dataSource = self
    }

    
   

    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition  = segue.identifier
        
        if(transition == "MummadiContactSegue")
        {
            let destination = segue.destination as! MummadiContactViewController
            
            destination.initials = C[(MummadiTVOL.indexPathForSelectedRow?.row)!][0]
            destination.phoneNumber = C[(MummadiTVOL.indexPathForSelectedRow?.row)!][1]
        }
    }
}

